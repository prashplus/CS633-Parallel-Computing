# Assignment 3

## CSE
* The main script is run.py (prefer python3).
* Checkhost script search out all the online nodes from the allhost files and store it in the hosts file.
* Make sure to recomile the source using 'make' before executing it. (make is already there in run.py)
* Suffle the host file before executing, since 1 -30 nodes are usually loading with jobs all the time.
* The command to execute the plot script from run.py is commented. (Uncomment if all the required libraries are present)
* The program is generating 1 output file (time data) per dataset. (for PLOT)
* The plot file is generating 2 graphs, each containing 3 plots.
* Cluster data is saved in cse/data1/* && cse/data2/*

## HPC
* The main script is run.sh. (not to submit /just run in bash shell)
* But you can individually submit sub1.sh and sub2.sh on PBS(each for one dataset).
* sub1.sh calls hpcrun1.py and sub2.sh calls hpcrun2.py (one for each dataset).
* hosts file will be generated which we need to be bother about much.
* Make sure to recomile the source using 'make' before executing it.(no need if we are submitting the sub.sh)
* The command to execute the plot script from hpcrun1.py or hpcrun2.py is commented. (Uncomment if all the required libraries are present)
* The program is generating 1 output file (time data) per dataset. (for PLOT)
* The plot file is generating 2 graphs, each containing 3 plots.
* Cluster data is saved in hpc/data1/* && hpc/data2/*


## Observation
* As expected as the number of processes increaeses (it gets distributed) the time for clustering decreases.

## Plots

## CSE

![Plots 1](cse/data1/plot1.png)

![Plots 2](cse/data2/plot2.png)

## HPC

![Plots 1](hpc/data1/plot1.png)

![Plots 2](hpc/data2/plot2.png)

## Authors

* **Prashant Piprotar** - - [PrashPlus](https://github.com/prashplus)