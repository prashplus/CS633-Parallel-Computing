#!/bin/bash
mpiicc -o main.out src.c
qsub sub1.sh
qsub sub2.sh
